"""Persistência local."""

