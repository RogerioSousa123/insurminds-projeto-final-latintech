"""Adaptadores de modelos conversacionais."""

